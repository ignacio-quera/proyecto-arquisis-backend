from __future__ import annotations

from .features import pilinfo

pilinfo(supported_formats=False)
